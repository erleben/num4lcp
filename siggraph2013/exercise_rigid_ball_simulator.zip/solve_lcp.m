function lambda = solve_lcp(A, b, lambda)

% TODO add your own solver code here!!!

end
